<?php
header('Content-Type: application/json');

const AppUrl = 'https://yademansystem.ir/ExpenseKeeper/';
const HOST = 'localhost';
const USER = 'yademan1_ExpenseKeeper_User';
const PASS = 'pb$0U[0GfR@F';
const DB = 'yademan1_ExpenseKeeper';
const DSN = 'mysql:host='.HOST.';dbname='.DB;
const HostEmail = 'mail.yademansystem.ir';
const UserEmail = 'info@yademansystem.ir';
const PassEmail = '=Z#MnMVk$QLs';
const UploadAvatarUrl = 'https://yademansystem.ir/ExpenseKeeper/uploads/avatars/';
const DefaultAvatarUrl = 'https://yademansystem.ir/ExpenseKeeper/assets/images/icons/default-avatar.png';