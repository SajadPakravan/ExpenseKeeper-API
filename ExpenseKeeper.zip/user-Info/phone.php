<?php
global $pdo;
include '../tools/db_connect.php';

postMethod();

$phone = $_POST['phone'] ?? '';

$id = authorization();

nullCheck($phone, 'phone');

if (preg_match('/^09[0-9]{9}$/', $phone)) {
    $verifyCode = createVerifyCode($phone);

        $url = 'https://smspanel.trez.ir/SendPatternCodeWithUrl.ashx';
        $data = array(
            'AccessHash' => '8377d671-44e4-4560-ab25-d6d3e9e1b267',
            'Mobile' => $phone,
            'PatternId' => '1348bcee-e71a-4556-a304-d6ef6843da96',
            'token1' => $verifyCode['code']
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            echo 'خطا در ارسال: ' . curl_error($ch);
        } else {
            echo 'پاسخ وب سرویس: ' . $response;
        }

        curl_close($ch);
        exit(json_encode(['status' => 'emailPhone Null', 'message' => 'ایمیل یا شماره تلفن همراه را وارد کنید']));
}